//
//  ViewController.h
//  Text to Speech
//
//  Created by Apple on 24/06/15.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *speachText;
@property (weak, nonatomic) IBOutlet UIButton *maleVoice;
@property (weak, nonatomic) IBOutlet UIButton *femaleVoice;
@end

