//
//  ViewController.m
//  Text to Speech
//
//  Created by Apple on 24/06/15.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import "ViewController.h"
@import AVFoundation;

@interface ViewController ()

@end

@implementation ViewController
@synthesize speachText;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)textToSpeach:(id)sender {
//    AVSpeechUtterance *utterance = [AVSpeechUtterance
//                                    speechUtteranceWithString:@"Hello world"];
//    AVSpeechSynthesizer *synth = [[AVSpeechSynthesizer alloc] init];
//    [synth speakUtterance:utterance];
    AVSpeechSynthesizer *synthesizer = [[AVSpeechSynthesizer alloc] init];
    AVSpeechUtterance *utterance = [[AVSpeechUtterance alloc] initWithString:speachText.text];
    utterance.rate = 0.15;
    //en-au, en-gb, en-us, en-GB
    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"en-au"];
    [synthesizer speakUtterance:utterance];
    synthesizer = nil;
}
- (IBAction)maleVoiceAction:(id)sender {
    
    AVSpeechSynthesizer *synthesizer = [[AVSpeechSynthesizer alloc] init];
    AVSpeechUtterance *utterance = [[AVSpeechUtterance alloc] initWithString:speachText.text];
    utterance.rate = 0.15;
    //en-au, en-gb, en-us, en-GB
    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"en-gb"];
    [synthesizer speakUtterance:utterance];
    synthesizer = nil;

}
- (IBAction)femaleVoiceAction:(id)sender {
    AVSpeechSynthesizer *synthesizer = [[AVSpeechSynthesizer alloc] init];
    AVSpeechUtterance *utterance = [[AVSpeechUtterance alloc] initWithString:speachText.text];
    utterance.rate = 0.15;
    //en-au, en-gb, en-us, en-GB
    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"en-au"];
    [synthesizer speakUtterance:utterance];
    synthesizer = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
